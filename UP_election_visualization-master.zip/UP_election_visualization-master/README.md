# Maharashtra_election_visualization
Plotting a choropleth map of Maharastra's 2019 assembly election from publicly available data.
